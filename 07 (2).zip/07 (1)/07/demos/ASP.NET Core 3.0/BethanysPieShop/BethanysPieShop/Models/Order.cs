﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BethanysPieShop.Models
{
    public class Order
    {
        [BindNever]
        public int OrderId { get; set; }
        public List<OrderDetail > OrderDetails { get; set; }
       
        [Required(ErrorMessage = "Please Enter your first name")]
        [Display(Name="First Name")]
        [StringLength(50)]

        public string FirstName { get; set; }
      
        [Required(ErrorMessage = "Please Enter your last name")]
        [Display(Name = "Last Name")]
        [StringLength(50)]

        public string LastName { get; set; }
       
        [Required(ErrorMessage = "Please Enter your Adress")]
        [Display(Name = "Address Line 1")]
        [StringLength(100)]
        public string Addressline1 { get; set; }

        [Required(ErrorMessage = "Please Enter your Adress")]
        [Display(Name = "Address Line 2")]
        public string Addressline2 { get; set; }

        [Required(ErrorMessage = "Please Enter your zip code")]
        [Display(Name = "Zip Code")]
        [StringLength(10,MinimumLength =4)]
        public string ZipCode { get; set; }

        [Required(ErrorMessage = "Please Enter your city")]
        [StringLength(50)]
        public string City { get; set; }

        [StringLength(10)]
        [Required(ErrorMessage = "Please Enter your state")]
        public string State { get; set; }

        [Required(ErrorMessage = "Please Enter your country")]
        [StringLength(50)]

        public string Country { get; set; }

        [Required(ErrorMessage = "Please Enter your phone number")]
        [StringLength(25)]
        [Display(Name = "Phone Number")]
        [DataType(DataType.PhoneNumber)]

        public string PhoneNumber { get; set; }

        [Required(ErrorMessage ="Please Enter required format")]
        [StringLength(50)]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z",
                            ErrorMessage = "Please enter a valid email address")]
        public string Email { get; set; }

        [BindNever]
        [ScaffoldColumn(false)]
        public decimal OrderTotal { get; internal set; }
        [BindNever]
        [ScaffoldColumn(false)]
        public DateTime OrderPlaced { get; internal set; }

        
    }
}
